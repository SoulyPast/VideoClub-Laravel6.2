<?php
echo "Benvingut {{$nom}}";
?>