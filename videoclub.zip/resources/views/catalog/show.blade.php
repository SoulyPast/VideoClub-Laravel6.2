@extends('layouts.master')
@section('content')
<div class="row">

    <div class="col-sm-4">

    <img src="{{$pelicula['poster']}}" style="height:350px"/>

    </div>
    <div class="col-sm-8">

    <h1>  {{$pelicula->title}}</h1>
    <h3>Año: {{$pelicula->year}}</h2>
    <h3>Director: {{$pelicula->director}}</h2>

    <p>
      <p>
        <span style="font-weight: bold;">Resumen:</span> {{$pelicula->synopsis}}
      </p>
    </p>

    <spam><strong>Estado: </strong></spam>
            @if($pelicula->rented)
                <spam>Pelicula actualmente alquilada</spam><p></p>
                <a class="btn btn-danger">Devolver pelicula</a>
            @else
                <spam>Pelicula disponible</spam><p></p>
                <a class="btn btn-info">Alquilar pelicula</a>
            @endif
            <a class="btn btn-warning" href="/newclub/videoclub/public/catalog/edit/{{$pelicula->id}}"><span class="glyphicon glyphicon-pencil"></span> Editar pelicula</a>
            <a type="button" class="btn btn-dark" href="/newclub/videoclub/public/catalog"><span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span> Volver al listado</a>
    </div>
</div>
@stop
