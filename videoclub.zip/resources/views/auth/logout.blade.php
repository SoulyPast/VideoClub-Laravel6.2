@extends('layouts.master')

@section('content')

    Logout Usuario

@stop